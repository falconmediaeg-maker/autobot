# Task Automator

## Overview
A web automation dashboard that allows users to create and manage automated web tasks. Features a dedicated NRJ voting page for عصام السقا with one-click voting.

## Tech Stack
- **Frontend**: React + TypeScript, Vite, TailwindCSS, shadcn/ui, TanStack Query, wouter
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Automation**: Puppeteer + Chromium headless browser automation

## Current NRJ Voting Setup
- **Target URL**: https://www.radionrjfm.com/vote/17
- **Candidate**: عصام السقا (Essam El Sakka) - أفضل ممثل مساعد
- **Checkbox selector**: `<input class="17" value="1" name="answers[289]" type="checkbox">`
- **Submit button**: `<button id="btnSub" type="submit">تصويت</button>`
- **Recommended delay**: 3000ms minimum to prevent memory crashes

## Proxy Status
- **Webshare**: Configured but currently down (proxy.webshare.io not responding)
  - URL: https://proxy.webshare.io/api/v2/proxy/list/download/jhsussaggvpmdkpqfocapypdszkjnjbarlxjmsrz/-/any/username/backbone/-/?plan_id=12867601
  - User said it was working before with NRJ - try again when it's back
- **Bright Data**: Account created (7 day trial), residential proxy configured
  - Host: brd.superproxy.io:33335
  - Username: brd-customer-hl_379284c8-zone-residential_proxy1
  - Password: nd62ycwuuxbu
  - ISSUE: Cloudflare blocks Bright Data IPs on NRJ site
  - TODO: User will try setting country to Egypt - might bypass Cloudflare
- **Direct (no proxy)**: Works fine, 36+19=55 successful votes so far

## Voting Progress
- Batch 1 (direct, no proxy): 36 successful, 0 failed
- Batch 2 (direct): 19 successful, 1 failed
- **Total: ~55 successful votes for عصام السقا**

## Structure
- `shared/schema.ts` - Database schema (tasks, taskLogs) and Zod types
- `server/storage.ts` - Database CRUD operations via Drizzle
- `server/routes.ts` - REST API endpoints + NRJ-specific endpoints
- `server/automator.ts` - Task execution engine with Puppeteer, memory optimizations
- `client/src/pages/nrj-vote.tsx` - Dedicated NRJ voting page (home page /)
- `client/src/pages/dashboard.tsx` - General task list view (/dashboard)
- `client/src/pages/create-task.tsx` - Task creation form
- `client/src/pages/task-detail.tsx` - Task detail with logs

## API Endpoints
- `GET /api/tasks` - List all tasks
- `POST /api/tasks` - Create a task
- `GET /api/tasks/:id` - Get task details
- `PATCH /api/tasks/:id` - Update task
- `DELETE /api/tasks/:id` - Delete task
- `POST /api/tasks/:id/run` - Start task execution
- `POST /api/tasks/:id/stop` - Stop task execution
- `GET /api/tasks/:id/logs` - Get task logs
- `DELETE /api/tasks/:id/logs` - Clear task logs
- `GET /api/nrj/status` - Get NRJ voting status
- `POST /api/nrj/start` - Start NRJ voting (body: {votes, delayMs})
- `POST /api/nrj/stop` - Stop NRJ voting

## Memory Optimizations (Chromium)
- `--single-process`, `--no-zygote` to reduce process count
- Block images, CSS, fonts, media via request interception
- `--js-flags=--max-old-space-size=128` to limit JS heap
- `domcontentloaded` instead of `networkidle2` for faster loads
- Minimum 2 second delay between runs enforced
- Anti-detection: random user agents, webdriver spoofing, language spoofing
- Page load validation: checks for chrome-error pages

## Chromium Path
`/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium`

## Next Steps
- Try Bright Data with Egypt country setting
- Try Webshare when it comes back online
- Both may work better than global IPs since NRJ is Egyptian
